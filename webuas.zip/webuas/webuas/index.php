<?php
    require "koneksi.php";
    $queryProduk = mysqli_query($con, "SELECT id, nama, harga, foto, detail FROM produk LIMIT 11");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perabotan ne Mazehh | HOME</title>
    <link href="image/shops.png" rel="icon">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php require "navbar.php"; ?>
    <!--banner-->
    <div class="container-fluid banner d-flex align-items-center">
        <div class="container text-center text-white">
            <h1>SELAMAT DATANG DI Perabotan ne Mazeh</h1>
            <h3>Silahkan, Apa yang mau dicari ?</h3>
            <div class="col-md-8 offset-md-2">
                <form method="get" action="produk.php">
                    <div class="input-group input-group-lg my-4">
                        <input type="text" class="form-control" placeholder="Silahkan dicari" aria-label="Recipient's username"
                        aria-describedby="basic-addon2" name = "keyword">
                        <button type="submit" class="btn color4 text-white">Pencarian</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--highlighted kategori-->
    <div class="container-fluid py-5">
        <div class="container text-center">
            <h3>KATEGORI PERABOTA  NE MAZEH</h3>
            <div class="row mt-5">
                <div class="col-md-4 mb-3">
                    <div class="highlighted-kategori kategori1 d-flex justify-content-center align-items-center">
                        <h4 class="text-white"><a class="no-decoration" href="produk.php?kategori=Kitchen">KITCHEN</a></h3>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="highlighted-kategori kategori2 d-flex justify-content-center align-items-center">
                        <h4 class="text-white"><a class="no-decoration" href="produk.php?kategori=Sittingroom">SITTING ROOM</a></h4>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="highlighted-kategori kategori3 d-flex justify-content-center align-items-center">
                        <H4 class="text-white"><a class="no-decoration" href="produk.php?kategori=Badroom">BAD ROOM</a></H4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--tentang kami-->
    <div class="container-fluid bg-dark text-white py-5">
        <div class="container text-center">
            <h3>TENTANG KAMI</h3>
            <p class='fs-5 mt-3'>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus veritatis, esse odit nam placeat sapiente obcaecati nisi eveniet fuga rem, sint earum et facere, magni pariatur quo atque. Sapiente quam voluptate ut hic? Fugit, velit? Quidem repudiandae quis aliquid odit eum, eveniet impedit magni quas saepe nobis ipsa, amet quaerat omnis voluptate facilis aperiam? Animi, perspiciatis quia rem eaque quos ipsa illo voluptatum quis maiores neque provident repudiandae? Quas suscipit autem sapiente. Natus dicta corporis similique aspernatur accusamus nihil adipisci?
            </p>
        </div>
    </div>
    <!--produk-->
    <div class="container-fluid py-5">
        <div class="container text-center">
            <h3>PRODUK</h3>

            <div class="row mt-5">
                <?php while($data = mysqli_fetch_array($queryProduk)){ ?>
                <div class="col-md-3 mb-5">
                    <div class="card h-100">
                        <div class="image-box">
                            <img src="image/<?php echo $data['foto']; ?>" class="card-img-top" alt="...">
                        </div>
                        <div class="card-body">
                            <h3 class="card-title"><?php echo $data['nama']; ?></h3>
                            <p class="card-text text-truncate"><?php echo $data['detail']; ?></p>
                            <p class="card-text text-harga">Rp<?php echo $data['harga']; ?></p>
                            <a href="produk-detail.php?nama=<?php echo $data['nama']; ?>" class="btn color2 text-black">Liat Detail</a>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
            <a href="produk.php" class="btn btn-outline-warning mt-3 p-4 fs-3">SEE MORE</a>
        </div>
    </div>
    <!--footer-->
    <?php require "footer.php"; ?>
    <script src="boostrap/js/boostrap.bundle.min.js"></script>
    <script src="fontawesome/js/all.min.js"></script>
</body>
</html>