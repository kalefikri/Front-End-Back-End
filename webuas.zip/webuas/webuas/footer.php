<div class="container-fluid py-5 latarbelakang text-light">
    <div class="container">
        <h5 class="text-center mb-4">IKUTI KAMI</h5>
        <div class="row justify-content-center">
            <div class="col-sm-1 d-flex justify-content-center mb-2">
                <a href="https://www.facebook.com"><i class="fa-brands fa-facebook-square fs-4"></i></a>
            </div>
            <div class="col-sm-1 d-flex justify-content-center mb-2">
                <a href="https://www.instagram.com"><i class="fa-brands fa-instagram fs-4"></i></a>
            </div>
            <div class="col-sm-1 d-flex justify-content-center mb-2">
                <a href="https://www.twitter.com"><i class="fa-brands fa-twitter fs-4"></i></a>
            </div>
            <div class="col-sm-1 d-flex justify-content-center mb-2">
                <a href="https://www.youtube.com"><i class="fa-brands fa-youtube fs-4"></i></a>
            </div>
            <div class="col-sm-1 d-flex justify-content-center mb-2">
                <a href="https://www.whatsapp.com"><i class="fa-brands fa-whatsapp fs-4"></i></a>
            </div>
        </div>
    </div>
</div>

<div class="comtainer-fluid py-3 bg-dark text-light">
    <div class="container d-flex justify-content-center">
        <label>&copy;2022 Perabota Ne Mazeh is created by Rehan Mumtaz</label>
    </div>
</div>