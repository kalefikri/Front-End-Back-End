<?php
    require "koneksi.php";

    $nama = htmlspecialchars($_GET['nama']);
    $queryProduk = mysqli_query($con, "SELECT * FROM produk WHERE nama = '$nama'");
    $produk = mysqli_fetch_array($queryProduk);

    $queryProdukTerkait = mysqli_query($con, "SELECT * FROM produk WHERE kategori_id = '$produk[kategori_id]' 
    AND id!= '$produk[id]' LIMIT 4");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penjualan Makanan | Produk Detail</title>
    <link href="image/shops.png" rel="icon">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php require "navbar.php";?>
    <!--produk detail-->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 mb-3">
                    <img src="image/<?php echo $produk['foto']; ?>" alt="" class="w-100">
                </div>
                <div class="col-lg-6 offset-lg-1">
                    <h1><?php echo $produk['nama']; ?></h1>
                    <p class="fs-5">
                        <?php echo $produk['detail']; ?>
                    </p>
                    <p class ="text-harga">
                        Rp <?php echo $produk['harga']; ?>
                    </p>
                    <p>Status Menu : <strong><?php echo $produk['ketersediaan_stok'];?></strong></p>
                </div>
            </div>
        </div>
    </div>
    <!--produk yang tertera-->
    <div class="container-fluid py-5 color1">
        <div class="container">
            <h2 class="text-center text-white mb-5">PRODUK YANG TERTERA</h2>

            <div class="row">
                <?php while($data=mysqli_fetch_array($queryProdukTerkait)){ ?>
                <div class="col-md-4 col-lg-3 mb-5">
                    <a href="produk-detail.php?nama=<?php echo $data['nama']; ?>">
                        <img src="image/<?php echo $data['foto']; ?>" alt="" class="img-fluid img-thumbnail image-box">
                    </a>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <!--footer-->
    <?php require "footer.php" ?>
    
    <script src="boostrap/js/boostrap.bundle.min.js"></script>
    <script src="fontawesome/js/all.min.js"></script>
</body>
</html>