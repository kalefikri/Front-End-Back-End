<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penjualan Makanan | Tentang Kami</title>
    <link href="image/shops.png" rel="icon">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php require "navbar.php"?>
    <!--banner-->
    <div class="container-fluid banner-produk d-flex align-items-center">
        <div class="container">
            <h1 class="text-white text-center">TENTANG KAMI</h1>
        </div>
    </div>
    <!--main-->
    <div class="container-fluid py-5">
        <div class="container fs-5 text-center">
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos optio deleniti incidunt exercitationem ab quaerat, quae qui blanditiis quisquam vitae voluptates, molestias iste voluptatem eveniet dolorem minus itaque odio aut unde consectetur mollitia esse veritatis laborum cum? At esse hic vero quas, deleniti libero? Eveniet laborum tempore eius placeat, eligendi corporis doloribus, ullam deserunt temporibus officia alias aliquam repudiandae cupiditate est nobis non architecto quasi in autem iusto cum veritatis quisquam laboriosam.
            Autem, eum eos nemo exercitationem, eveniet ullam placeat, sunt hic atque esse tempora quod aliquid voluptatibus neque? Accusamus harum aut ab sed sunt molestias minus laudantium possimus velit quod error reiciendis veritatis ipsa reprehenderit tenetur aspernatur molestiae nisi, a vitae dolorum dolores. Repudiandae illum error nam amet optio sint ipsam, aut perspiciatis provident nostrum debitis delectus quae vitae quas sunt officiis ipsum dolores? Eos illum laudantium harum sequi facere esse beatae cumque voluptas veniam officiis dolor eligendi molestiae enim, dignissimos voluptate sed hic odit molestias assumenda omnis illo facilis? Quidem, error? Nihil aperiam culpa nulla, fuga amet cumque odio in eius, veniam officiis ipsum inventore voluptate laboriosam impedit ipsam laborum! Temporibus iusto voluptatibus sint minima sapiente dignissimos dolores id consequatur. Minus corrupti accusamus deserunt aliquid ex debitis adipisci.
        </p>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos optio deleniti incidunt exercitationem ab quaerat, quae qui blanditiis quisquam vitae voluptates, molestias iste voluptatem eveniet dolorem minus itaque odio aut unde consectetur mollitia esse veritatis laborum cum? At esse hic vero quas, deleniti libero? Eveniet laborum tempore eius placeat, eligendi corporis doloribus, ullam deserunt temporibus officia alias aliquam repudiandae cupiditate est nobis non architecto quasi in autem iusto cum veritatis quisquam laboriosam.
            Autem, eum eos nemo exercitationem, eveniet ullam placeat, sunt hic atque esse tempora quod aliquid voluptatibus neque? Accusamus harum aut ab sed sunt molestias minus laudantium possimus velit quod error reiciendis veritatis ipsa reprehenderit tenetur aspernatur molestiae nisi, a vitae dolorum dolores. Repudiandae illum error nam amet optio sint ipsam, aut perspiciatis provident nostrum debitis delectus quae vitae quas sunt officiis ipsum dolores? Eos illum laudantium harum sequi facere esse beatae cumque voluptas veniam officiis dolor eligendi molestiae enim, dignissimos voluptate sed hic odit molestias assumenda omnis illo facilis? Quidem, error? Nihil aperiam culpa nulla, fuga amet cumque odio in eius, veniam officiis ipsum inventore voluptate laboriosam impedit ipsam laborum! Temporibus iusto voluptatibus sint minima sapiente dignissimos dolores id consequatur. Minus corrupti accusamus deserunt aliquid ex debitis adipisci.
        </p>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos optio deleniti incidunt exercitationem ab quaerat, quae qui blanditiis quisquam vitae voluptates, molestias iste voluptatem eveniet dolorem minus itaque odio aut unde consectetur mollitia esse veritatis laborum cum? At esse hic vero quas, deleniti libero? Eveniet laborum tempore eius placeat, eligendi corporis doloribus, ullam deserunt temporibus officia alias aliquam repudiandae cupiditate est nobis non architecto quasi in autem iusto cum veritatis quisquam laboriosam.
            Autem, eum eos nemo exercitationem, eveniet ullam placeat, sunt hic atque esse tempora quod aliquid voluptatibus neque? Accusamus harum aut ab sed sunt molestias minus laudantium possimus velit quod error reiciendis veritatis ipsa reprehenderit tenetur aspernatur molestiae nisi, a vitae dolorum dolores. Repudiandae illum error nam amet optio sint ipsam, aut perspiciatis provident nostrum debitis delectus quae vitae quas sunt officiis ipsum dolores? Eos illum laudantium harum sequi facere esse beatae cumque voluptas veniam officiis dolor eligendi molestiae enim, dignissimos voluptate sed hic odit molestias assumenda omnis illo facilis? Quidem, error? Nihil aperiam culpa nulla, fuga amet cumque odio in eius, veniam officiis ipsum inventore voluptate laboriosam impedit ipsam laborum! Temporibus iusto voluptatibus sint minima sapiente dignissimos dolores id consequatur. Minus corrupti accusamus deserunt aliquid ex debitis adipisci.
        </p>
        </div>
    </div>

    <!--footer-->
    <?php require "footer.php" ?>
    <script src="boostrap/js/boostrap.bundle.min.js"></script>
    <script src="fontawesome/js/all.min.js"></script>
</body>
</html>